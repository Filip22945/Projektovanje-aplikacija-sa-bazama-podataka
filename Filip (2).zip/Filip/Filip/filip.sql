-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2024 at 10:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `filip`
--

-- --------------------------------------------------------

--
-- Table structure for table `alat`
--

CREATE TABLE `alat` (
  `id` int(11) NOT NULL,
  `naziv_alata` varchar(90) NOT NULL,
  `primena` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alat`
--

INSERT INTO `alat` (`id`, `naziv_alata`, `primena`) VALUES
(2, 'Pištolj za farbanje', 'Lakse nanosenje farbe u jednakom sloju'),
(16, 'Brusilica za poliranje', 'Prilikom poliranja za nanosenje polir paste'),
(17, 'Dijagnostika', 'Radi lakseg pronalaska kvara na automobilu sto se tice elektronike'),
(18, 'Digitalni multimetar', 'Merenje napona, struje i otpora u električnim krugovima.'),
(19, 'Test Lampica', 'Brza proba električnih strujnih krugova i napona.'),
(20, 'Osciloskop', 'Praćenje i analiziranje električnih signala i njihovih promena tokom vremena.'),
(21, 'Ključevi', 'Otvaranje i zatvaranje vijaka i matica.'),
(22, 'Dizalica', 'Podizanje teških vozila ili objekata za popravke ili servis.'),
(23, 'Set za rad sa motorom', 'Različite aktivnosti u održavanju i popravci motora, uključujući zamenu delova i prilagođavanje.'),
(24, 'Set za zavarivanje', ' Zavarivanje metalnih delova za stvaranje trajnih spojeva.'),
(25, 'Čekić i Dleta', 'Oblikovanje i sečenje metala ili drveta.'),
(26, 'Alati za Oblikovanje Metala', 'Oblikovanje i savijanje metalnih delova u željeni oblik.'),
(27, 'Pneumatski Ključevi', 'Brza i efikasna demontaža i montaža vijaka i matica, često korišćeni u industriji i servisima.'),
(28, 'Limarski Čekić (Tucak)', 'Oblikovanje i ispravljanje metalnih delova, često korišćen za popravke karoserije vozila.'),
(29, 'Elektro-izolacijska Traka', 'Omotavanje i zaštita električnih žica i spojeva, pomaže u zaštiti od kratkog spoja i električnih uda'),
(30, 'Rezač Metala', 'Precizno sečenje metalnih ploča i cevi.'),
(31, 'Brusilica', 'Brušenje i poliranje metalnih površina, uklanjanje nečistoća i završna obrada metalnih delova.');

-- --------------------------------------------------------

--
-- Table structure for table `klijent`
--

CREATE TABLE `klijent` (
  `id` int(20) NOT NULL,
  `ime` varchar(50) NOT NULL,
  `prezime` varchar(50) NOT NULL,
  `servis` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `klijent`
--

INSERT INTO `klijent` (`id`, `ime`, `prezime`, `servis`) VALUES
(1, 'Jelena', 'Jovanovic', 'mehanicar, limar'),
(4, 'Milica', 'Petrovic', 'elektricar'),
(5, 'Lazar ', 'Lazarevic', 'limar'),
(6, 'Petar', 'Pejovic', 'mehanicar'),
(11, 'Stevan', 'Djusic', 'mehanicar, elektricar');

-- --------------------------------------------------------

--
-- Table structure for table `zaposleni`
--

CREATE TABLE `zaposleni` (
  `id` int(11) NOT NULL,
  `ime` varchar(20) NOT NULL,
  `prezime` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `pozicija` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `zaposleni`
--

INSERT INTO `zaposleni` (`id`, `ime`, `prezime`, `email`, `pozicija`, `password`) VALUES
(1, 'Mika', 'Mikic', 'mika@gmail.com', 'Auto elektricar i mehanicar', '202cb962ac59075b964b07152d234b70'),
(3, 'Laza', 'Lazic', 'laza@gmail.com', 'Mehanicar', '202cb962ac59075b964b07152d234b70'),
(4, 'Stevan', 'Milosevic', 'stevica@gmail.com', 'Limar', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alat`
--
ALTER TABLE `alat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `klijent`
--
ALTER TABLE `klijent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zaposleni`
--
ALTER TABLE `zaposleni`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alat`
--
ALTER TABLE `alat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `klijent`
--
ALTER TABLE `klijent`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `zaposleni`
--
ALTER TABLE `zaposleni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
