<?php
include("povezivanje.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete"])) {
    if (isset($_POST["id"])) {
        $id = $_POST["id"];

        $stmt = $mysqli->prepare("DELETE FROM klijent_servisi WHERE klijent_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        $stmt = $mysqli->prepare("DELETE FROM klijent WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            header("Location: ../klijenti.php?success=1");
            exit();
        } else {
            echo "Greška prilikom brisanja klijenta: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Nedostaje ID klijenta.";
    }
} else {
    echo "Neispravan zahtev za brisanje.";
}

$mysqli->close();
?>
