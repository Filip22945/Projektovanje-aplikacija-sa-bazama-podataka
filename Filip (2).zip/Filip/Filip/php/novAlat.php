<?php

include("povezivanje.php");

$naziv_alata = $_POST['naziv_alata'];
$primena = $_POST['primena'];

if ($mysqli->connect_error) {
    die("Neuspelo povezivanje s bazom podataka: " . $mysqli->connect_error);
}

$statement = $mysqli->prepare("INSERT INTO alat (naziv_alata, primena) VALUES (?, ?)");

if (!$statement) {
    die("Greška prilikom pripreme upita: " . $mysqli->error);
}

$statement->bind_param("ss", $naziv_alata, $primena);

if ($statement->execute()) {
    header("Location: ../novAlat.php?success=1");
} else {
    die("Error : (" . $mysqli->errno . ") " . $mysqli->error);
}

$statement->close();
$mysqli->close();
?>
