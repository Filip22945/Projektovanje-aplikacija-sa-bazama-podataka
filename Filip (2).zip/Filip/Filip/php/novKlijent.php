<?php
include("povezivanje.php");

$ime = $_POST['ime'];
$prezime = $_POST['prezime'];
$servisi = isset($_POST['servis']) ? implode(', ', $_POST['servis']) : '';

if ($mysqli->connect_error) {
    die("Neuspelo povezivanje s bazom podataka: " . $mysqli->connect_error);
}

$statement = $mysqli->prepare("INSERT INTO klijent (ime, prezime, servis) VALUES (?, ?, ?)");

if (!$statement) {
    die("Greška prilikom pripreme upita: " . $mysqli->error);
}

$statement->bind_param("sss", $ime, $prezime, $servisi);

if ($statement->execute()) {
    header("Location: ../novKlijent.php?success=1");
} else {
    die("Error : (" . $mysqli->errno . ") " . $mysqli->error);
}

$statement->close();
$mysqli->close();
?>
