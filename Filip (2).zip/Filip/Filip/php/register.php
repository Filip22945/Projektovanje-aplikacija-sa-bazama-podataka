<?php

// Uključuje fajl koji sadrži kod za uspostavljanje veze sa bazom podataka
include_once("povezivanje.php");

// Dohvata lozinke iz zahteva
$password = $_REQUEST["password"];
$lozinka2 = $_REQUEST["lozinka2"];

// Provjerava da li se unete lozinke poklapaju
if ($password != $lozinka2) {
    // Ako lozinke nisu iste, preusmerava korisnika na stranicu za registraciju sa GET parametrom za grešku
    die(header("location: ../register.php?error=1"));
} else {
    // Ako su lozinke iste, dohvaća ostale podatke iz zahteva
    $ime = $_REQUEST["ime"];
    $prezime = $_REQUEST["prezime"];
    $email = $_REQUEST["email"];
    $pozicija = $_REQUEST["pozicija"];

    // Izvršava SQL upit za proveru da li već postoji korisnik sa unetim emailom
    $query = $mysqli->query("SELECT * FROM zaposleni WHERE email='$email'");
    $num = $query->num_rows;
    // Ako postoji korisnik sa istim emailom, preusmerava na stranicu za registraciju sa GET parametrom za grešku
    if ($num > 0) {
        die(header("location: ../register.php?error=2"));
    }

    // Priprema SQL upit za umetanje novog korisnika u tabelu 'zaposleni'
    $statement = $mysqli->prepare("INSERT INTO zaposleni (ime, prezime, email, pozicija, password) VALUES (?, ?, ?, ?, ?)");

    // Veže varijable za pripremljeni izraz, enkriptuje lozinku koristeći MD5
    $statement->bind_param('sssss', $ime, $prezime, $email, $pozicija, md5($password));

    // Izvršava pripremljeni SQL upit
    if ($statement->execute()) {
        // Ako je umetanje uspešno, preusmerava korisnika na početnu stranicu sa GET parametrom za uspeh
        header("location: ../index.php?success=1");
    } else {
        // Ako dođe do greške prilikom umetanja, prikazuje grešku i prekida izvršavanje
        die('Error:(' . $mysqli->errno . ') ' . $mysqli->error);
    }
}
?>
