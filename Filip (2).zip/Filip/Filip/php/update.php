<?php
include("povezivanje.php");

$id = $_POST['id'];
$ime = $_POST['ime'];
$prezime = $_POST['prezime'];
$email = $_POST['email'];
$pozicija = $_POST['pozicija'];

$stmt = $mysqli->prepare("UPDATE zaposleni SET ime = ?, prezime = ?, email = ?, pozicija = ? WHERE id = ?");
$stmt->bind_param("ssssi", $ime, $prezime, $email, $pozicija, $id);

if ($stmt->execute()) {
    header("Location: ../zaposleni.php"); 
} else {
    echo "Greška pri ažuriranju: " . $stmt->error;
}

$stmt->close();
$mysqli->close();
?>
