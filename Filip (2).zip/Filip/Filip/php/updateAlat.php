<?php
include("povezivanje.php");

$id = $_POST['id'];
$naziv_alata = $_POST['naziv_alata'];
$primena = $_POST['primena'];

$stmt = $mysqli->prepare("UPDATE alat SET naziv_alata = ?, primena = ? WHERE id = ?");

$stmt->bind_param("ssi", $naziv_alata, $primena, $id);

if ($stmt->execute()) {
    header("Location: ../alati.php"); 
} else {
    echo "Greška pri ažuriranju: " . $stmt->error;
}

$stmt->close();
$mysqli->close();
?>
