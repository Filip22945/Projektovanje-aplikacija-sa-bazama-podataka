<?php
include("povezivanje.php");

$id = $_POST['id']; 
$ime = $_POST['ime']; 
$prezime = $_POST['prezime']; 

$servisi = isset($_POST['servis']) ? implode(', ', $_POST['servis']) : '';

$stmt = $mysqli->prepare("UPDATE klijent SET ime = ?, prezime = ?, servis = ? WHERE id = ?");

$stmt->bind_param("sssi", $ime, $prezime, $servisi, $id);

if ($stmt->execute()) {
    header("Location: ../klijenti.php?success=1"); 
} else {
    echo "Greška pri ažuriranju klijenta: " . $stmt->error;
}

$stmt->close();
$mysqli->close();
?>
