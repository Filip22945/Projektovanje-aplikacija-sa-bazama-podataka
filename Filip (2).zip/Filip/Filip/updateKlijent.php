<?php
include("php/povezivanje.php");

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    header("Location: klijenti.php");
    exit;
}

$query = $mysqli->prepare("SELECT * FROM klijent WHERE id = ?");
$query->bind_param("i", $id);
$query->execute();
$data = $query->get_result()->fetch_object();

if (!$data) {
    header("Location: klijenti.php");
    exit;
}

$query->close();
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css">
    <title>Ažuriraj klijenta</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card text-white bg-dark">
                    <div class="card-header">
                        <h3>Ažuriraj klijenta</h3>
                    </div>
                    <div class="card-body">
                        <form action="php/updateKlijent.php" method="post">
                            <input type="hidden" name="id" value="<?php echo $data->id; ?>">
                            <div class="form-group">
                                <label for="ime">Ime klijenta</label>
                                <input type="text" name="ime" class="form-control" value="<?php echo htmlspecialchars($data->ime); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="prezime">Prezime klijenta</label>
                                <input type="text" name="prezime" class="form-control" value="<?php echo htmlspecialchars($data->prezime); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="servis">Servis</label>
                                <div class="form-check">
                                    <input type="checkbox" name="servis[]" value="mehanicar" id="mehanicar" <?php if (strpos($data->servis, 'mehanicar') !== false) echo 'checked'; ?>>
                                    <label for="mehanicar" class="form-check-label">Mehaničar</label>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="servis[]" value="elektricar" id="elektricar" <?php if (strpos($data->servis, 'elektricar') !== false) echo 'checked'; ?>>
                                    <label for="elektricar" class="form-check-label">Auto električar</label>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="servis[]" value="limar" id="limar" <?php if (strpos($data->servis, 'limar') !== false) echo 'checked'; ?>>
                                    <label for="limar" class="form-check-label">Limar</label>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Ažuriraj klijenta</button>
                            <a href="klijenti.php" class="btn btn-secondary">Nazad na klijente</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>

</html>
